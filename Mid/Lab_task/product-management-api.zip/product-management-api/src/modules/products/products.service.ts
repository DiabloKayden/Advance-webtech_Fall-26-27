import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { Product } from "./entities/product.entity";
import { CreateProductDto } from "./dto/create-product.dto";
import { UpdateProductDto } from "./dto/update-product.dto";
@Injectable()
export class ProductsService {
  constructor(@InjectRepository(Product) private readonly repo: Repository<Product>) {}
  create(dto: CreateProductDto) { return this.repo.save(this.repo.create({ ...dto, stock: dto.stock ?? 0 })); }
  findAll() { return this.repo.find({ order: { id: "ASC" } }); }
  async findOne(id: number) {
    const row = await this.repo.findOne({ where: { id } });
    if (!row) throw new NotFoundException(`Product with ID ${id} not found`);
    return row;
  }
  async update(id: number, dto: UpdateProductDto) {
    const row = await this.findOne(id); Object.assign(row, dto); return this.repo.save(row);
  }
  async remove(id: number) {
    const row = await this.findOne(id); await this.repo.remove(row);
    return { message: `Product with ID ${id} deleted successfully` };
  }
}
