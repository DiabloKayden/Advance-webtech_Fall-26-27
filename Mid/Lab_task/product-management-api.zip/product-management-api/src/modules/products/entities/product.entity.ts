import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
@Entity({ name: "products" })
export class Product {
  @PrimaryGeneratedColumn() id: number;
  @Column({ type: "varchar", length: 150 }) name: string;
  @Column({ type: "text", nullable: true }) description: string | null;
  @Column({ type: "decimal", precision: 10, scale: 2, default: 0 }) price: string;
  @Column({ type: "int", default: 0 }) stock: number;
  @CreateDateColumn() createdAt: Date;
  @UpdateDateColumn() updatedAt: Date;
}
