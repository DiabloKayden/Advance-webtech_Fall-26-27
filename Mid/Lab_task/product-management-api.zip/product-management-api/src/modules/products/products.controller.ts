import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post } from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { ProductsService } from "./products.service";
import { CreateProductDto } from "./dto/create-product.dto";
import { UpdateProductDto } from "./dto/update-product.dto";
@ApiTags("Products")
@Controller("products")
export class ProductsController {
  constructor(private readonly service: ProductsService) {}
  @Post() @ApiOperation({ summary: "Create a product" }) create(@Body() dto: CreateProductDto) { return this.service.create(dto); }
  @Get() @ApiOperation({ summary: "Get all products" }) findAll() { return this.service.findAll(); }
  @Get(":id") @ApiOperation({ summary: "Get product by ID" }) findOne(@Param("id", ParseIntPipe) id: number) { return this.service.findOne(id); }
  @Patch(":id") @ApiOperation({ summary: "Update a product" }) update(@Param("id", ParseIntPipe) id: number, @Body() dto: UpdateProductDto) { return this.service.update(id, dto); }
  @Delete(":id") @ApiOperation({ summary: "Delete a product" }) remove(@Param("id", ParseIntPipe) id: number) { return this.service.remove(id); }
}
