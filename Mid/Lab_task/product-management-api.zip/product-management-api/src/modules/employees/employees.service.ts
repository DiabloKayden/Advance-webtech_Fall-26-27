import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { Employee } from "./entities/employee.entity";
import { CreateEmployeeDto } from "./dto/create-employee.dto";
import { UpdateEmployeeDto } from "./dto/update-employee.dto";
@Injectable()
export class EmployeesService {
  constructor(@InjectRepository(Employee) private readonly repo: Repository<Employee>) {}
  create(dto: CreateEmployeeDto) { return this.repo.save(this.repo.create({ ...dto, salary: dto.salary ?? 0 })); }
  findAll() { return this.repo.find({ order: { id: "ASC" } }); }
  async findOne(id: number) {
    const row = await this.repo.findOne({ where: { id } });
    if (!row) throw new NotFoundException(`Employee with ID ${id} not found`);
    return row;
  }
  async update(id: number, dto: UpdateEmployeeDto) {
    const row = await this.findOne(id); Object.assign(row, dto); return this.repo.save(row);
  }
  async remove(id: number) {
    const row = await this.findOne(id); await this.repo.remove(row);
    return { message: `Employee with ID ${id} deleted successfully` };
  }
}
