import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post } from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { EmployeesService } from "./employees.service";
import { CreateEmployeeDto } from "./dto/create-employee.dto";
import { UpdateEmployeeDto } from "./dto/update-employee.dto";
@ApiTags("Employees")
@Controller("employees")
export class EmployeesController {
  constructor(private readonly service: EmployeesService) {}
  @Post() @ApiOperation({ summary: "Create an employee" }) create(@Body() dto: CreateEmployeeDto) { return this.service.create(dto); }
  @Get() @ApiOperation({ summary: "Get all employees" }) findAll() { return this.service.findAll(); }
  @Get(":id") @ApiOperation({ summary: "Get employee by ID" }) findOne(@Param("id", ParseIntPipe) id: number) { return this.service.findOne(id); }
  @Patch(":id") @ApiOperation({ summary: "Update an employee" }) update(@Param("id", ParseIntPipe) id: number, @Body() dto: UpdateEmployeeDto) { return this.service.update(id, dto); }
  @Delete(":id") @ApiOperation({ summary: "Delete an employee" }) remove(@Param("id", ParseIntPipe) id: number) { return this.service.remove(id); }
}
