import { IsEmail, IsNumber, IsOptional, IsString, Min, MinLength } from "class-validator";
import { Type } from "class-transformer";
export class CreateEmployeeDto {
  @IsString() @MinLength(1) name: string;
  @IsEmail() email: string;
  @IsString() @MinLength(1) position: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) salary?: number;
}
