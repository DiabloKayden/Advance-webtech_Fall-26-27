import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
@Entity({ name: "employees" })
export class Employee {
  @PrimaryGeneratedColumn() id: number;
  @Column({ type: "varchar", length: 120 }) name: string;
  @Column({ type: "varchar", length: 180, unique: true }) email: string;
  @Column({ type: "varchar", length: 100 }) position: string;
  @Column({ type: "decimal", precision: 10, scale: 2, default: 0 }) salary: string;
  @CreateDateColumn() createdAt: Date;
  @UpdateDateColumn() updatedAt: Date;
}
