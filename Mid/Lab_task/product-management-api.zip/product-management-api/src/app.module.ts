import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { TypeOrmModule } from "@nestjs/typeorm";
import { BullModule } from "@nestjs/bull";
import { PostgresDatabaseProviderModule } from "@/providers/database/postgres/provider.module";
import global_config from "@/config/global_config";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { Product } from "./modules/products/entities/product.entity";
import { Employee } from "./modules/employees/entities/employee.entity";
import { ProductsModule } from "./modules/products/products.module";
import { EmployeesModule } from "./modules/employees/employees.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ConfigModule.forRoot({ isGlobal: true, load: [global_config] }),
    PostgresDatabaseProviderModule,
    TypeOrmModule.forFeature([Product, Employee]),
    BullModule.forRoot({ url: process.env.REDIS_URL || "redis://localhost:6379" }),
    ProductsModule,
    EmployeesModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
