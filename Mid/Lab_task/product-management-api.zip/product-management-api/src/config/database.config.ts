import { DefaultNamingStrategy, NamingStrategyInterface, DataSourceOptions } from "typeorm";
import { camelCase, snakeCase } from "typeorm/util/StringUtils";
import * as dotenv from "dotenv";
dotenv.config();

export class SnakeNamingStrategy extends DefaultNamingStrategy implements NamingStrategyInterface {
  tableName(className: string, customName: string): string {
    if (customName) return customName;
    return `${snakeCase(className)}s`;
  }
  columnName(propertyName: string, customName: string, embeddedPrefixes: string[]): string {
    return snakeCase(embeddedPrefixes.join("_")) + (customName || snakeCase(propertyName));
  }
  relationName(propertyName: string): string { return camelCase(propertyName, true); }
  joinColumnName(relationName: string, referencedColumnName: string): string {
    return snakeCase(`${relationName}_${referencedColumnName}`);
  }
  joinTableName(firstTableName: string, secondTableName: string, firstPropertyName: string): string {
    return snakeCase(`${firstTableName}_${firstPropertyName.replace(/\./gi, "_")}_${secondTableName}`);
  }
  joinTableColumnName(tableName: string, propertyName: string, columnName?: string): string {
    return snakeCase(`${tableName}_${columnName || propertyName}`);
  }
  classTableInheritanceParentColumnName(parentTableName: string, parentTableIdPropertyName: string): string {
    return snakeCase(`${parentTableName}_${parentTableIdPropertyName}`);
  }
}

export const dataSourceOptions: DataSourceOptions = {
  type: "postgres",
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 5432,
  username: process.env.DB_USER || "postgres",
  password: process.env.DB_PASSWORD || "postgres",
  database: process.env.DB_DATABASE || "product_management",
  schema: "public",
  entities: [__dirname + "/../modules/**/entities/*.entity.{ts,js}"],
  namingStrategy: new SnakeNamingStrategy(),
  migrations: [__dirname + "/../database/migrations/*.ts"],
  logging: false,
  synchronize: true,
};
