import { NestFactory } from "@nestjs/core";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { NestExpressApplication } from "@nestjs/platform-express";
import * as dotenv from "dotenv";
import { Request, Response, NextFunction } from "express";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import { join } from "path";
import { AppModule } from "./app.module";

dotenv.config();

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.useStaticAssets(join(process.cwd(), "uploads"), { prefix: "/uploads/" });
  app.getHttpAdapter().getInstance().set("trust proxy", true);
  app.use(helmet({ crossOriginEmbedderPolicy: false }));
  app.use((req: Request, res: Response, next: NextFunction) => {
    const now = new Date().toISOString().replace("T", " ").replace(/\..+/, "");
    console.log(`[HTTP] [${now}] ${req.method} ${req.originalUrl}`);
    next();
  });
  const config = new DocumentBuilder()
    .setTitle("Product Management API")
    .setDescription("Lab Task 1: Product and Employee CRUD endpoints")
    .setVersion("1.0")
    .addBearerAuth()
    .build();
  SwaggerModule.setup("api", app, SwaggerModule.createDocument(app, config));
  app.use(cookieParser(process.env.COOKIE_SECRET || "lab-development-secret"));
  const origins = process.env.CORS_ORIGINS
    ? process.env.CORS_ORIGINS.split(",").map((origin) => origin.trim())
    : ["http://localhost:3000"];
  app.enableCors({ origin: origins, credentials: true, methods: ["GET", "POST", "PUT", "PATCH", "DELETE"], maxAge: 86400 });
  await app.listen(parseInt(process.env.PORT || "5001", 10));
}
bootstrap();
