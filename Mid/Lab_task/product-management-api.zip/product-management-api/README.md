# Product Management API — Lab Task 1

**Student Name:** ABDUL AZIZ JIHAN  
**Student ID:** 22-46518-2  
**Section:** B

## Project overview
A REST API created by extending the faculty-provided NestJS boilerplate. It implements database-backed CRUD operations for Products and Employees using NestJS, TypeORM, and PostgreSQL.

## How the boilerplate is used
The original project structure and reusable configuration are retained, including `src/common`, `src/config`, `src/providers`, Swagger setup, request logging, CORS, and the PostgreSQL/TypeORM provider. Lab-specific entities, DTOs, controllers, services, and modules are added under `src/modules/products` and `src/modules/employees`.

## Requirements
- Node.js 22 or later (as stated in the faculty boilerplate README)
- PostgreSQL
- pnpm (recommended; original `pnpm-lock.yaml` retained)
- Redis is configured by the original Bull module setup; a local URL is used by default.

## Setup
1. Create a PostgreSQL database named `product_management`.
2. Copy `.env.example` to `.env` and edit the database username/password to match your local PostgreSQL setup.
3. Install dependencies: `pnpm install` (or `npm install`).
4. Start development server: `pnpm start:dev` (or `npm run start:dev`).
5. Base URL: `http://localhost:5001`.
6. Swagger docs: `http://localhost:5001/api`.

**Coursework note:** TypeORM `synchronize: true` is enabled to create the tables automatically. This setting is not recommended for production.

## Product endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | `/products` | Create product |
| GET | `/products` | List products |
| GET | `/products/:id` | Get product by ID |
| PATCH | `/products/:id` | Update product |
| DELETE | `/products/:id` | Delete product |

Example JSON:
```json
{
  "name": "Wireless Mouse",
  "description": "USB wireless mouse",
  "price": 850,
  "stock": 20
}
```

## Employee endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | `/employees` | Create employee |
| GET | `/employees` | List employees |
| GET | `/employees/:id` | Get employee by ID |
| PATCH | `/employees/:id` | Update employee |
| DELETE | `/employees/:id` | Delete employee |

Example JSON:
```json
{
  "name": "Samira Khan",
  "email": "samira@example.com",
  "position": "Sales Assistant",
  "salary": 28000
}
```

## Postman
Import `postman/NestJS-Lab-Task-1.postman_collection.json` into Postman. Update the `baseUrl` variable if your API host/port differs. Capture your own genuine test screenshots and save them in `screenshots/`.

## Structure
```text
product-management-api/
├── src/
│   ├── common/                 # retained boilerplate utilities
│   ├── config/                 # environment and database config
│   ├── database/               # retained migration structure
│   ├── modules/
│   │   ├── products/           # entity, DTOs, controller, service, module
│   │   └── employees/          # entity, DTOs, controller, service, module
│   ├── providers/              # retained boilerplate providers
│   ├── app.module.ts
│   └── main.ts
├── postman/
├── screenshots/
├── .env.example
├── package.json
└── pnpm-lock.yaml
```
